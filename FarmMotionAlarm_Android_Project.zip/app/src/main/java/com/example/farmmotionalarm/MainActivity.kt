package com.example.farmmotionalarm

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.camera.core.Preview
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    // DEMO ONLY: change this before sharing. A key embedded in an APK can be extracted.
    private val activationKey = "FARM-ALARM-2026"
    private lateinit var status: TextView
    private lateinit var previewView: PreviewView
    private lateinit var keyInput: EditText
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var cameraProvider: ProcessCameraProvider? = null
    private var tone: ToneGenerator? = null
    @Volatile private var running = false
    @Volatile private var lastAlarmMs = 0L
    @Volatile private var previous: ByteArray? = null
    @Volatile private var previousWidth = 0
    @Volatile private var previousHeight = 0
    private var motionThreshold = 18
    private var alarmCooldownMs = 8000L

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startCamera()
        else status.text = "Camera permission denied. Allow Camera in Settings."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tone = ToneGenerator(AudioManager.STREAM_MUSIC, 100)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val title = TextView(this).apply {
            text = "Farm Motion Alarm"
            textSize = 24f
        }
        val instructions = TextView(this).apply {
            text = "Enter activation key. Keep phone powered and aimed at the field. Any movement may trigger the alarm."
            textSize = 15f
        }
        keyInput = EditText(this).apply {
            hint = "Activation key"
            singleLine = true
        }
        val activateButton = Button(this).apply {
            text = "Activate"
            setOnClickListener {
                if (keyInput.text.toString().trim() == activationKey) {
                    status.text = "Activated. Connect Bluetooth speaker if desired."
                    startButton.isEnabled = true
                    Toast.makeText(this@MainActivity, "Activation successful", Toast.LENGTH_SHORT).show()
                } else {
                    status.text = "Invalid activation key."
                }
            }
        }
        status = TextView(this).apply {
            text = "Not activated"
            textSize = 16f
        }
        previewView = PreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        }
        startButton = Button(this).apply {
            text = "Start monitoring"
            isEnabled = false
            setOnClickListener {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED) startCamera()
                else permissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
        stopButton = Button(this).apply {
            text = "Stop monitoring"
            setOnClickListener { stopCamera() }
        }
        val testButton = Button(this).apply {
            text = "Test alarm"
            setOnClickListener { playAlarm() }
        }
        root.addView(title)
        root.addView(instructions)
        root.addView(keyInput)
        root.addView(activateButton)
        root.addView(status)
        root.addView(previewView)
        root.addView(startButton)
        root.addView(stopButton)
        root.addView(testButton)
        setContentView(root)
    }

    private fun startCamera() {
        if (running) return
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            cameraProvider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setTargetResolution(android.util.Size(320, 240))
                .build()
            analysis.setAnalyzer(cameraExecutor) { image -> analyzeFrame(image) }
            try {
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                )
                running = true
                status.text = "Monitoring. Motion triggers alarm; false alarms are possible."
            } catch (e: Exception) {
                status.text = "Could not start camera: ${e.message}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(image: ImageProxy) {
        try {
            val plane = image.planes.firstOrNull() ?: return
            val buffer = plane.buffer
            val data = ByteArray(buffer.remaining())
            buffer.get(data)
            val width = image.width
            val height = image.height
            // Compare downsampled luminance. This is simple motion detection, NOT animal recognition.
            val sampleW = 32
            val sampleH = 24
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride
            val current = ByteArray(sampleW * sampleH)
            for (y in 0 until sampleH) {
                for (x in 0 until sampleW) {
                    val sx = x * width / sampleW
                    val sy = y * height / sampleH
                    val idx = sy * rowStride + sx * pixelStride
                    if (idx in data.indices) current[y * sampleW + x] = data[idx]
                }
            }
            val old = previous
            if (old != null && previousWidth == sampleW && previousHeight == sampleH && running) {
                var changed = 0
                var totalDiff = 0
                for (i in current.indices) {
                    val diff = abs((current[i].toInt() and 0xff) - (old[i].toInt() and 0xff))
                    if (diff > motionThreshold) changed++
                    totalDiff += diff
                }
                val changedRatio = changed.toFloat() / current.size
                val avgDiff = totalDiff.toFloat() / current.size
                val now = System.currentTimeMillis()
                // Threshold is deliberately conservative; tune in real field conditions.
                if (changedRatio > 0.12f && avgDiff > 9f && now - lastAlarmMs > alarmCooldownMs) {
                    lastAlarmMs = now
                    runOnUiThread { status.text = "Movement detected — alarm playing." }
                    playAlarm()
                }
            }
            previous = current
            previousWidth = sampleW
            previousHeight = sampleH
        } catch (_: Exception) {
            // Ignore occasional bad camera frames.
        } finally {
            image.close()
        }
    }

    private fun playAlarm() {
        // Short repeating tones, routed by Android to the currently selected media output.
        try {
            tone?.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1800)
        } catch (_: Exception) {
            Toast.makeText(this, "Could not play alarm", Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopCamera() {
        running = false
        previous = null
        cameraProvider?.unbindAll()
        status.text = "Monitoring stopped."
    }

    override fun onDestroy() {
        stopCamera()
        tone?.release()
        cameraExecutor.shutdown()
        super.onDestroy()
    }
}
